﻿using System;

namespace Geometry
{
    public class EmptyClass
    {
        public EmptyClass ()
        {
            
        }
    }
}

